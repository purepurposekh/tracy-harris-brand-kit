# Tracy Harris Co · Brand Kit Components

Exported 2026-06-11. Structure: styles/ holds the shared design tokens and fonts; components/<family>/ holds each family's shared CSS and its variants/ as standalone HTML.

To use a variant elsewhere: load styles/fonts.css + styles/tokens.css, include the family CSS, copy the variant's body markup, and keep a data-brand attribute (tracy | ffb | ffm | fresh) on a wrapper.
